#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX_RULES 10
#define MAX_APPS 5

typedef struct {
    char appName[50];
    char allowedIP[20];
    char protocol[10]; 
    int allowedPort;
} FirewallRule;

FirewallRule rules[MAX_RULES];
int ruleCount = 0;

void loadFirewallRules() {
    
    strcpy(rules[0].appName, "chrome.exe");
    strcpy(rules[0].allowedIP, "8.8.8.8");
    strcpy(rules[0].protocol, "TCP");
    rules[0].allowedPort = 443;

    strcpy(rules[1].appName, "notepad.exe");
    strcpy(rules[1].allowedIP, "0.0.0.0");
    strcpy(rules[1].protocol, "NONE");
    rules[1].allowedPort = 0;

    ruleCount = 2;
}

int isAllowed(char *app, char *ip, int port, char *protocol) {
    for (int i = 0; i < ruleCount; i++) {
        if (strcmp(rules[i].appName, app) == 0 &&
            strcmp(rules[i].allowedIP, ip) == 0 &&
            strcmp(rules[i].protocol, protocol) == 0 &&
            rules[i].allowedPort == port) {
            return 1;
        }
    }
    return 0;
}

void logEvent(const char *app, const char *ip, int port, const char *protocol, const char *status) {
    FILE *f = fopen("agent_log.txt", "a");
    if (!f) return;
    time_t now = time(NULL);
    fprintf(f, "[%s] %s tried to access %s:%d via %s - %s\n", ctime(&now), app, ip, port, protocol, status);
    fclose(f);
}

int main() {
    char app[50], ip[20], protocol[10];
    int port;

    loadFirewallRules();
    printf("=== Context-Aware Firewall Agent Simulation ===\n");

    while (1) {
        printf("\nEnter Application Name (or type 'exit'): ");
        fgets(app, sizeof(app), stdin);
        app[strcspn(app, "\n")] = 0;

        if (strcmp(app, "exit") == 0)
            break;

        printf("Enter Destination IP: ");
        fgets(ip, sizeof(ip), stdin);
        ip[strcspn(ip, "\n")] = 0;

        printf("Enter Destination Port: ");
        scanf("%d", &port);
        getchar(); 

        printf("Enter Protocol (TCP/UDP): ");
        fgets(protocol, sizeof(protocol), stdin);
        protocol[strcspn(protocol, "\n")] = 0;

        if (isAllowed(app, ip, port, protocol)) {
            printf("? Connection ALLOWED by policy.\n");
            logEvent(app, ip, port, protocol, "ALLOWED");
        } else {
            printf("? Connection BLOCKED by policy.\n");
            logEvent(app, ip, port, protocol, "BLOCKED");
        }
    }

    printf("Firewall agent simulation ended. Logs saved in 'agent_log.txt'\n");
    return 0;
}

